+++
date = '2025-12-20T11:12:46+08:00'
draft = false
title = '备忘录'
categories = ['生活']
+++


hugo的一些命令 防止忘记

新增文章
hugo new posts/2-post.md

网站预览
hugo server