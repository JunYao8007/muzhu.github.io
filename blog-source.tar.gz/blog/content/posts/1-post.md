+++
date = '2025-12-20T10:19:14+08:00'
draft = false
title = 'hello hugo'
categories = ['生活']
+++



当你看到这个文章时

hugo已经安装成功了

感谢 suus.me 的指导 才有了第一个属于自己的静态博客